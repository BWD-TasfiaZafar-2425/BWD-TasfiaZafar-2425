# Praktijkdeel: CSS

Bouw aan de hand van de bijgeleverde screenshots de pagina zo precies mogelijk na.
- gebruik de bijgeleverde HTML; je mag het waar nodig uitbreiden met id- en classattributen
- de gebruikte kleuren kan je met de colorpicker plugin vinden (open de screenshot in de browser)
- de gebruikte lettertypes zijn Khula en Lato (dit zijn Google fonts)
- voorzie hovereffecten en transities
- let op layout en linting!

LET OP: 
- je mag gebruik maken van het internet, de cursus, eigen code en alle A.I. tools
- je mag GEEN gebruik maken van tools/apps/programma's die het delen van code mogelijk maken (OneDrive, Discord, mail, sociale media...) op straffe van een fraudedossier 

Indienen:
- upload je oplossing in één zip **op Toledo**
- push het ook **op je repo** in de map Test2/Praktijk (de submap "Praktijk" moet je zelf aanmaken)

